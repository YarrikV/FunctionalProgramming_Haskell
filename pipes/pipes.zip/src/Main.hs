module Main where

import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Data.Bitmap   (loadBMP)
import System.Environment (getArgs)
import Control.Monad      (when)
import Data.List
import Data.Either  (fromLeft, fromRight)
import ParserBoard
import ParserInit
import Types
import Display
import Constants
import Functions


--      Process

main :: IO ()
main = do
  args <- getArgs

  -- This is to test.
  if length args > 1

    then do
      let (opt:worldFile:_) = args
      when (opt /= "--test") (putStrLn $ "Unidentified option: "++opt++", didn't you mean: --test? \nRunning --test instead:")
      worldString <- readFile worldFile
      let parsed = fst . head $ apply parseBoard worldString
      case parsed of
        Left err      -> print err
        Right world'  -> do
          let world = checkStatus $ changeGears $ makeHole world'
          print (status world)

    -- This is to play.
    else
      if length args == 1

        then do
          worldString <- readFile $ head args
          let parsed = fst . head $ apply parseBoard worldString
          case parsed of
            Left err      -> print err
            Right world'  -> do
              tilePicts <- mapM loadBMP allTilePaths
              let world = checkStatus $ changeGears $ makeHole world'
                  string_picture_list = zip allTileStrings tilePicts
                  render = worldToPicture string_picture_list
              play window backgroundcolor fps world
                   render processInput processTime

        else

          putStrLn notEnoughArgs


-- | Auxiliary function for the processing of the input.
isKey k1 (EventKey k2 Down  _ _ )  = k1 == k2
isKey _  _  = False

-- | Function which processes the input.
processInput :: Event -> World -> World
processInput _ w@(World _ _ _ _ _ _ Completed) = w
processInput key@(EventKey _ _ _ co) w@(World d _ _ _ _ hole _)
    | isKey (MouseButton LeftButton) key && neighbour poskey hole = checkStatus $ move poskey w
    | isKey (Char 'q') key || isKey (SpecialKey KeyLeft) key  = checkStatus $ move (addCo hole ( 1, 0)) w
    | isKey (Char 'd') key || isKey (SpecialKey KeyRight) key = checkStatus $ move (addCo hole (-1, 0)) w
    | isKey (Char 'z') key || isKey (SpecialKey KeyUp) key    = checkStatus $ move (addCo hole ( 0, 1)) w
    | isKey (Char 's') key || isKey (SpecialKey KeyDown) key  = checkStatus $ move (addCo hole ( 0,-1)) w
    | otherwise = w
      where poskey = position d co
            neighbour coord hole = coord `elem` neighboursAll hole
processInput _ w = w


-- | Nothing should happen with the world if time passes.
processTime :: Float -> World -> World
processTime _ w = w
