module Display where

import Graphics.Gloss.Data.Display
import Graphics.Gloss.Data.Picture
import Graphics.Gloss.Interface.Pure.Display
import Graphics.Gloss.Interface.Pure.Game
import Data.Maybe (fromJust)
import Control.Monad (liftM, fmap)
import Types
import Constants
import Functions (addCo, isGeared, isNoGeared, isSink)
import Debug.Trace

--      Display

-- | Determins type of Display.
window :: Display
window = FullScreen

-- | De backgroundcolor.
backgroundcolor :: Color
backgroundcolor = white

-- | The foregroundcolor.
foregroundcolor :: Color
foregroundcolor = white

-- | A box around the playing field.
box :: (Int, Int) -> Picture
box (width, height) =  Color foregroundcolor (rectangleSolid scaleW scaleH)
                       where scaleW = fromIntegral (scale' * width)
                             scaleH = fromIntegral (scale' * height)

-- | Turns a coordinate into the right position on the screen.
transToCoord :: Coordinate -> Coordinate -> Picture -> Picture
transToCoord (width,height) (x,y) =
  translate dx dy
  where dx = fromIntegral ((x - (width `div` 2))* scale' + ds)
        dy = fromIntegral (((height `div` 2)- y)* scale' + ds)
        ds = scale' `div` 2

-- | Turns a tile into an appropriate Picture depending on its characteristics.
tileToPict :: [(String, Picture)] -> Coordinate -> Tile -> Picture
tileToPict string_picture_list dim tile
  | isNoGeared tile = transToCoord dim (coo tile) pictback
  | otherwise       = pictures $ map (transToCoord dim (coo tile)) [pictback, pictfront]
  where pictfront = fromJust $ lookup s_front string_picture_list
        pictback  = fromJust $ lookup s_back  string_picture_list
        s_type | isGeared tile = "tile"
               | isSink   tile = "sink"
               | otherwise     = "source"
        s_rot  | rot tile == Clockwise = "clockwise"
               | otherwise     = "counter"
        s_spin | spin tile     = "turning"
               | otherwise     = "stopped"
        s_front = s_type ++ "_" ++ s_rot ++ "_" ++ s_spin
        s_back | fixed tile    = "fixed"
               | otherwise     = "loose"


-- | Transforms a World to a Picture, as requested by the play function.
worldToPicture :: [(String, Picture)] -> World -> Picture
worldToPicture s_p_list (World dms so si tls_nog tls_g hole _) =
  pictures ( map (tileToPict s_p_list dms) (so ++ si ++ tls_nog ++ tls_g) ++
             [transToCoord dms hole (fromJust $ lookup "hole" s_p_list)] )
