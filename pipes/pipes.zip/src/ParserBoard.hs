module ParserBoard (
  parseBoard
) where

import ParserInit
import Types
import Functions (isGeared)

import Data.List      (lookup, (\\))
import Data.Char      (isSpace)
import Control.Monad  (when)


tokenWidth   = "width"
tokenHeight  = "height"
tokenSources = "sources"
tokenSinks   = "sinks"
tokenTiles   = "tiles"

tokenClock   = "clockwise"
tokenCounter = "counter clockwise"

tokenListI   = '{'
tokenListF   = '}'
tokenCoordI  = '('
tokenCoordF  = ')'
sep          = ','

tokenYes     = "yes"
tokenNo      = "no"

tokenPos     = "pos"
tokenFixed   = "fixed"
tokenWheel   = "wheel"


isHSpace :: Char -> Bool
isHSpace c | c == '\n' = False
           | otherwise = isSpace c

isVSpace :: Char -> Bool
isVSpace c = ('\n' == c) || ('\r' == c)

hWhite :: ErrorParser String
hWhite = greedyPlus (spot isHSpace NoHSpace)
optHWhite = greedyStar (spot isHSpace NoHSpace)

vWhite :: ErrorParser Char
vWhite = token '\n' <|> token '\r'

white :: ErrorParser String
white = greedyStar (spot isSpace NoSpace)

keyPair' :: String -> ErrorParser a -> ErrorParser a
keyPair' key valP = do match key
                       token ':'
                       hWhite
                       valP

parseList' :: ErrorParser a -> ErrorParser [a]
parseList' p = do white
                  token tokenListI
                  white
                  val <- p
                  vals <- greedyStar (do white
                                         token sep
                                         white
                                         p)
                  white
                  token tokenListF
                  return (val:vals)

parseCoord' :: ErrorParser Coordinate
parseCoord' =  do token tokenCoordI
                  optHWhite
                  x1 <- parseNat
                  optHWhite
                  token sep
                  optHWhite
                  x2 <- parseNat
                  optHWhite
                  token tokenCoordF
                  return (x1,x2)

parseRot' :: ErrorParser Rotation
parseRot' = (match tokenClock >> return Clockwise) <|> (match tokenCounter >> return Counter)

-------------------------------------------------------------------------------

keyPair :: String -> ErrorParser a -> ErrorParser a
keyPair key valP = catchE (keyPair' key valP) (message $ KeyParseFail key)

parseYesNo :: ErrorParser Bool
parseYesNo = (match tokenYes >> return True) <|> (match tokenNo >> return False)

parseList :: ErrorParser a -> ErrorParser [a]
parseList p = catchE (parseList' p) (message FailedList)

parseCoord :: ErrorParser Coordinate
parseCoord = catchE parseCoord' (message FailedCoord)

parseWidth :: ErrorParser Int
parseWidth = keyPair tokenWidth parseNat

parseHeight :: ErrorParser Int
parseHeight = keyPair tokenHeight parseNat

parseRot :: ErrorParser Rotation
parseRot = catchE parseRot' (message FailedRotation)

--check als haakjes goed geparsed worden (vgl met tiles parser)
parseGate :: ErrorParser (Coordinate, Rotation)
parseGate = do  token tokenListI
                white
                co <- parseCoord
                token sep
                white
                rot <- parseRot
                white
                token tokenListF
                return (co, rot)

-- TODO iets met een case als je het volgend woord parsed en het is
-- bv fixed dan moet je de fixed parsen, bij pos moet je pos parsen etc
parseTile :: ErrorParser (Coordinate, Bool, Bool)
parseTile = do token tokenListI
               white
               co <- keyPair tokenPos parseCoord
               token sep
               white
               fixed <- keyPair tokenFixed parseYesNo
               token sep
               white
               wheel <- keyPair tokenWheel parseYesNo
               white
               token tokenListF
               return (co, fixed, wheel)

-- | Parses a World.
parseBoard :: ErrorParser World
parseBoard = do  w <- parseWidth
                 vWhite
                 h <- parseHeight
                 vWhite
                 srcs <- keyPair tokenSources $ parseList parseGate
                 vWhite
                 snks <- keyPair tokenSinks $ parseList parseGate
                 vWhite
                 tiles <- keyPair tokenTiles $ parseList parseTile
                 white
                 throwWhen (length tiles /= w * h - 1) NotTheRightAmountOfTiles
                 return (World (h, w) (createSrcs srcs) (createSnks snks) (filter ( not . isGeared) $ map createTile tiles) (filter isGeared $ map createTile tiles) (-6,-9) InProgress)
           where
               createSrcs = map (\(c, r) -> Source c True r True)
               createSnks = map (\(c, r) -> Sink c True r False)
               createTile :: (Coordinate, Bool, Bool) -> Tile
               createTile (co, fixed, True) = Tile_Geared co fixed NoRot False
               createTile (co, fixed, _)    = Tile_NoGear co fixed
