module ParserInit (
  ErrorParser(..),
  ParseError(..),
  greedyPlus,
  greedyStar,
  token,
  parseNat,
  match,
  catchE,
  throwE,
  message,
  spot,
  (<|>),
  parse,
  throwWhen
) where

import Control.Applicative
import Control.Monad
import Data.Char (isDigit)
import Debug.Trace
import Data.Either (either)

data ParseError = EOF
                | UnExpectedChar Char Char
                | UnExpectedWord String
                | NoNumber
                | NoDigitFound Char
                | NoHSpace Char
                | KeyParseFail String
                | NoSpace Char
                | FailedCoord
                | FailedList
                | FailedRotation
                | NotTheRightAmountOfTiles
                | StreamNoDry deriving (Show)

newtype ErrorParser a = ErrorParser {apply :: String -> [(Either [ParseError] a, String)]}

instance Functor ErrorParser where
  fmap f fa = ErrorParser $ \s -> [(fmap f a, s') | (a,s') <- apply fa s]

instance Applicative ErrorParser where
  pure x = ErrorParser $ \s -> [(Right x, s)]
  af <*> aa = ErrorParser $ \s -> [(f <*> a, s'') | (f,s') <- apply af s,
                                                    (a,s'') <- apply aa s']

instance Monad ErrorParser where
  return = pure
  p >>= f = ErrorParser $ \s -> do (a,s') <- apply p s
                                   case a of
                                     Right x -> apply (f x) s'
                                     Left y -> return (Left y, s')

instance Alternative ErrorParser where
  empty   = ErrorParser $ \s -> [(Left [], s)]
  m <|> n = ErrorParser $ \s -> do (x1, s1) <- apply m s
                                   (x2, s2) <- apply n s
                                   case x1 of
                                     Right ans -> return (x1, s1)
                                     Left wrong -> either (\w -> return (Left (wrong ++ w),s1)) (\r -> return (Right r,s2)) x2


greedyPlus :: ErrorParser a -> ErrorParser [a]
greedyPlus p = do x <- p
                  xs <- greedyStar p
                  return (x:xs)

greedyStar :: ErrorParser a -> ErrorParser [a]
greedyStar p = greedyPlus p <|> return []

getContext :: ErrorParser String
getContext = ErrorParser $ \s -> [(Right s, s)]

throwE :: ParseError -> ErrorParser a
throwE pe = ErrorParser $ \s -> [(Left [pe], s)]

throwWhen :: Bool -> ParseError -> ErrorParser ()
throwWhen False er = return ()
throwWhen True er = throwE er

message :: ParseError -> [ParseError] -> ErrorParser a
message p ps = ErrorParser $ \s -> [(Left (p:ps), s)]

catchE :: ErrorParser a -> ([ParseError] -> ErrorParser a) -> ErrorParser a
catchE p h = ErrorParser $ \s -> do (x1,s1) <- apply p s
                                    case x1 of
                                      Left l -> apply (h l) s1
                                      Right x -> return (x1,s1)



spot :: (Char -> Bool) -> (Char -> ParseError) -> ErrorParser Char
spot p er = ErrorParser $ \s -> case s of
                                  [] -> [(Left [EOF],[])]
                                  (x:xs) -> if p x then
                                              [(Right x, xs)]
                                            else
                                              [(Left [er x], x:xs)]

token :: Char -> ErrorParser Char
token c = spot (c==) (UnExpectedChar c)

match' :: String -> ErrorParser String
match' [] = return []
match' (x:xs) = do y <- token x
                   ys <- match' xs
                   return (y:ys)

match :: String -> ErrorParser String
match word = catchE (match' word) (message $ UnExpectedWord word)

parseNat' :: ErrorParser Int
parseNat' = do token '-'
               s <- greedyPlus (spot isDigit NoDigitFound)
               return (read ("-"++s))
        <|> do s <- greedyPlus (spot isDigit NoDigitFound)
               return (read s)


parseNat :: ErrorParser Int
parseNat = catchE parseNat' (message NoNumber)

parse:: String -> ErrorParser a -> Either [ParseError] a
parse s parser = getResult [x |  (x,t) <- apply parser s, t==""]
            where getResult [y] = y --TODO remove fst head
                  getResult []  = fst . head $ apply parser s
                  getResult ys  = Left [StreamNoDry]
