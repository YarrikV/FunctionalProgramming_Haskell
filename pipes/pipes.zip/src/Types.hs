module Types where

data World = World { dim :: (Int, Int) -- Dimensions
                   , sources :: [Tile]
                   , sinks :: [Tile]
                   , tiles_noGear :: [Tile]
                   , tiles_Geared :: [Tile]
                   , hole :: Coordinate
                   , status :: Status
                   }
spacefiller = concat $ replicate 40 "-"
instance Show World where
  show (World dim so si tls_nog tls_g hole status)
    = spacefiller++"\nWorld\nDimensions: "++show dim++"\nSources: "++
      show so++"\n\nSinks: "++show si++"\n\nNon-Geared Tiles: "++
      show tls_nog++"\n\nGeared Tiles: "++show tls_g++"\n\nHole at "++
      show hole++".\nCurrently the game is "++show status++"\n"++spacefiller++"\n\n"

data Tile     = Tile_NoGear  { coo   :: Coordinate
                             , fixed :: Bool
                             }
              | Tile_Geared  { coo    :: Coordinate
                             , fixed  :: Bool
                             , rot    :: Rotation
                             , spin   :: Bool}
              | Sink  { coo   :: Coordinate
                      , fixed :: Bool
                      , rot   :: Rotation
                      , spin  :: Bool}
              | Source { coo  :: Coordinate
                       , fixed :: Bool
                       , rot  :: Rotation
                       , spin :: Bool} deriving (Show, Eq)

data Rotation = NoRot | Clockwise | Counter deriving (Show, Eq)
type Coordinate = (Int, Int)

data Status   = InProgress | Completed | InValid
instance Show Status where
  show InProgress = "NOT SOLVED"
  show Completed  = "SOLVED"
  show _          = "INVALID"


  -- www = World (2,2) [Source (-1,0) True Clockwise True] [Sink (2,0) True Counter False] [] [(Tile_Geared  (0,0) False Counter True), (Tile_Geared (1,0) False Clockwise True), (Tile_Geared (1,1) False Counter True)] (1,0) InProgress
