module Functions where

import Types
import Data.Maybe (fromJust)
import Data.List  (find, elemIndex, nub, delete)
import Constants
import Debug.Trace

--        AUXILIARY FUNCTIONS

isGeared :: Tile -> Bool
isGeared Tile_Geared{} = True
isGeared _             = False

isNoGeared :: Tile -> Bool
isNoGeared Tile_NoGear{} = True
isNoGeared _             = False

isSource :: Tile -> Bool
isSource Source{} = True
isSource _        = False

isSink :: Tile -> Bool
isSink  Sink{}    = True
isSink  _         = False

position :: Coordinate -> (Float,Float) -> Coordinate
position (height, width) (x,y) = (dx, dy)
            where dx = floor ((x  + (fromIntegral width * fromIntegral scale' / 2)) / fromIntegral scale')
                  dy = round (((fromIntegral height + 1) * fromIntegral scale' / 2 - y) / fromIntegral scale')

validPos :: (Int, Int) -> Coordinate -> Bool
validPos (w,h) (x,y)  = x >= 0 && y >= 0 && x < w && y < h

neighboursAll :: Coordinate -> [Coordinate]
neighboursAll co = map (addCo co) directions

common :: Eq a => [a] -> [a] -> [a]
common [] _ = []
common _ [] = []
common (x:xs) ys | x `elem` ys = x:common xs (delete x ys)
                 | otherwise   = common xs ys

tiles :: World -> [Tile]
tiles w = tiles_Geared w ++ tiles_noGear w

splitTilesToGear :: [Tile] -> ([Tile], [Tile]) -> ([Tile], [Tile])
splitTilesToGear [] split_tls = split_tls
splitTilesToGear (t@Tile_NoGear{}:tls) (no_gs, gs)
  = splitTilesToGear tls (t:no_gs, gs)
splitTilesToGear (t@Tile_Geared{}:tls) (no_gs, gs)
  = splitTilesToGear tls (no_gs, t:gs)

neighbourGearedTiles :: World -> Tile -> ([Tile], [Tile])
neighbourGearedTiles w t = (neighbourTiles, others)
  where neighbourTiles  = filter (\tile -> coo tile `elem` neighboursAll (coo t)) (tiles_Geared w)
        others          = filter (`notElem` neighbourTiles) (tiles_Geared w)

addCo :: Coordinate -> Coordinate -> Coordinate
addCo (a,b) (c,d) = (a+c, b+d)


-- | With given world and a starting tile (will only be a sink/source), gives back
-- | all the connected tiles.
-- | findNetwork World (Tiles to scan) (Tiles connected)
findNetwork :: World -> [Tile] -> [Tile] -> [Tile]
findNetwork w [] tls = tls
findNetwork w (t:tls) connected_tls
  | null connected_tls  = findNetwork w (tls++new_tls) (t:connected_tls ++ new_tls)
  | otherwise           = findNetwork w (tls++new_tls) (connected_tls ++ new_tls)
    where
      new_tls = filter (\t -> coo t `notElem` map coo connected_tls) $ fst $  neighbourGearedTiles w{tiles_Geared = tiles_Geared w ++ sinks w ++ sources w} t

goodRot :: [Tile] -> Bool
goodRot network = all blacK network || all whitE network
  where
    -- compare with damboard pattern (black and white tiles)
    blacK = checkRot Clockwise Counter
    whitE = checkRot Counter Clockwise
    checkRot evenRot unevenRot tile
      | mod (x+y) 2 == 0  = rot tile == evenRot
      | otherwise         = rot tile == unevenRot
        where
          (x,y) = coo tile


--        SETUP

-- | Add a hole to the world. (Coordinate with no tile)
makeHole :: World -> World
makeHole wo@(World (w,h) src snk tls_nog tls_g _ _) = wo {hole = head rest}
  where full = [ (x,y) | x <- [0..w-1], y <- [0..h-1]]
        tiles = map coo (src++snk++tls_nog++tls_g)
        rest = filter (`notElem` tiles) full


--        PROCESS

-- | Moves the tile that has been clicked.
move :: Coordinate -> World -> World
move co w  | co == hole w || not (validPos (dim w) co) || fixed clicked_tile   = w
           | validPos (dim w) co && co `elem` neighboursAll (hole w)  = w { hole = co , tiles_Geared = gs, tiles_noGear = no_gs }
           | otherwise                  = w
  where match t       = co == coo t
        clicked_tile  = head $ filter match (tiles w) --that filter shouold return exactly 1 element.
        others        = filter (not . match) (tiles w)
        (no_gs, gs)   = splitTilesToGear (clicked_tile{coo = hole w}:others) ([],[])


--        CHECKSTATUS

changeGears' :: World -> [Tile] -> [Coordinate] -> World
changeGears' w [] _ = w -- Job's done!
changeGears' w (tile:todo_tls) done_cos
  | coo tile `elem` done_cos = changeGears' w todo_tls done_cos
  | otherwise = changeGears' new_w (todo_tls++new_tls) (coo tile : done_cos)
    where
      new_w = w { tiles_Geared = new_tls++others }
      (neighboursTiles, others) = neighbourGearedTiles w tile
      new_rot | rot tile == Clockwise = Counter
              | otherwise = Clockwise
      new_tls = map (\t -> t{rot = new_rot}) neighboursTiles

-- | Starting with all the source tiles, will change the rotation.
changeGears :: World -> World
changeGears w = changeGears' w (sources w) []


-- | Checks if a network of gears can spin, or if they are stopped.
-- | Only checks all the Sinks/Sources in a network for good rotation.
changeSpin' :: World -> [Tile] -> World
changeSpin' w [] = w
changeSpin' w (so:srcs) = changeSpin' (
          w { sources = filter isSource (new++others)
            , sinks = filter isSink (new++others)
            , tiles_Geared = filter isGeared (new++others)
            } ) srcs
  where
    new = map (\t -> t { spin = goodRot si_so_network && goodAmount si_so_network }) network
    goodAmount l  = length (filter isSource l) == length (filter isSink l)
    si_so_network = filter (\t -> isSource t || isSink t) network
    network       = findNetwork w [so] []
    others  = filter (\t -> coo t `notElem` map coo network) (tiles_Geared w ++ sinks w ++ sources w)

-- | Every time the spins are set, enables rotation of all the sources.
changeSpin :: World ->  World
changeSpin w = changeSpin' w (sources w)


-- | Checks the status of the world, assumed that #sources = #sinks
checkStatus' :: World -> World
checkStatus' w
  | equalNumbers && allGoodRot  = w { status = Completed }
  | otherwise                   = w { status = InProgress }
    where
      networks = map (\so -> findNetwork w [so] []) $ sources w
      equalNumbers = all (\list -> length (filter isSink list) == length (filter isSource list)) networks
      allGoodRot = all goodRot networks

checkStatus :: World -> World
checkStatus w = checkStatus' $ changeSpin $ changeGears $ w { tiles_Geared = map (spin False)  $ tiles_Geared w, sinks = map (spin False) $ sinks w, sources = map (spin True) $ sources w}
  where
    spin b t = t { spin = b }
