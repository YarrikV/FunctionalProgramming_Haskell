import Types
import Functions
import ParserBoard
import ParserInit

gateList :: [(Coordinate, Rotation)]
gateList  = [((1,2), NoRot), ((0,0), Clockwise), ((4,3), Counter)]

ww :: World
ww = World  (2,2)
            [Source (1,2) Clockwise False]
            [Sink (0,-1) Clockwise False]
            []
            [Tile_Geared (0,1) False NoRot False,
            Tile_Geared (1,1) True NoRot False,
            Tile_Geared (1,0) False NoRot False]
            (0,0)
            InProgress


www :: World
co_geared_www = [(0,0), (1,0), (1,1), (2,1), (0,2)]
www = World (3,3)
            [Source (-1,2) Counter False, Source (1,-1) Clockwise False]
            [Sink (0,3) Counter False, Sink (3,1) Clockwise False]
            [Tile_NoGear (0,1) True, Tile_NoGear (1,2) True, Tile_NoGear (2,0) False]
            (map (\co -> Tile_Geared co False NoRot False) co_geared_www)
            (2,2)
            InProgress

networksTest = map (\so -> findNetwork www [so] []) $ sources www

tlstest :: [Tile]
tlstest = [Tile_Geared (1,2) False NoRot False,
           Tile_Geared (2,2) False Clockwise False,
           Tile_Geared (0,0) True  Counter False,
           Tile_Geared (1,3) True  Clockwise False]

cootest :: [Coordinate]
cootest = [(1,2), (4,1), (3,1), (0,0), (2,2)]
