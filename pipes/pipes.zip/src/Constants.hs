module Constants (
  scale',
  fps,
  directions,
  allTilePaths,
  allTileStrings,
  notEnoughArgs
) where

import Types

-- | Scale of the pictures.
scale' :: Int
scale' = 96

-- | Refresh rate (per second).
fps :: Int
fps = 60

-- | All directions:
up :: Coordinate
up    = ( 0,-1)
right :: Coordinate
right = ( 1, 0)
down :: Coordinate
down  = ( 0, 1)
left :: Coordinate
left  = (-1, 0)
directions = [up, down, right, left]

-- | FilePaths & Lists to do your lookup in.
tileType  = ["source", "sink", "tile"]
tileRot   = ["clockwise", "counter"]
tileSpin  = ["turning", "stopped"]

difftiles = [t ++ "_" ++ r ++ "_" ++ s | t <- tileType, r <- tileRot, s <- tileSpin]
others    = ["fixed", "loose", "hole"]
allTilePaths  = map ((++ ".bmp") . ("./bmp/" ++)) (difftiles ++ others)
allTileStrings = difftiles ++ others

notEnoughArgs = "Not enough arguments given, expected 1 (boardfile) or more (--test option and directory of boardfiles)."
